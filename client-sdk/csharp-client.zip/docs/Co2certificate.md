# IO.Swagger.Model.Co2certificate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Compensation** | **string** | Digital Identity of CO2 compensation certificate. | [optional] 
**Co2** | **int?** | Gram CO2eq covered by this certificate | [optional] 
**Co2requested** | **int?** | Requested CO2 to offset. Might be less than actual co2 covered by certficate due to minimum amounts. | [optional] 
**Signature** | **string** | Digital Signature as generated during transfer of ownership. | [optional] 
**Owner** | **string** | Digital Identity of owner of this certificate | [optional] 
**Tree** | **string** | Digital Identity of actual tree in case type of compensation is planting a tree. | [optional] 
**Meta** | **Object** | Meta Information attached during transfer of ownership. Covers fields like original activity etc..  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

