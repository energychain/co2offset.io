# IO.Swagger.Model.Co2basket
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Checkout** | **string** | URL for interactive checkout and payment of CO2 offset for a co2 certificate. | [optional] 
**Credit** | **int?** | CO2 credit of your account (if authenticated) | [optional] 
**Debit** | **string** | CO2 debit of your account (if authenticated) | [optional] 
**Intermediate** | **string** | Temporary Certificate | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

