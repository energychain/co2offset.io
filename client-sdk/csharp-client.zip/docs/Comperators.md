# IO.Swagger.Model.Comperators
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Nature/Kind to compare with | [optional] 
**Value** | [**decimal?**](BigDecimal.md) | Quantity | [optional] 
**Units** | **string** | units of this nature/kind | [optional] 
**Description** | **string** | Quantity calculation description | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

