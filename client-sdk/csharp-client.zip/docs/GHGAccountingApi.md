# IO.Swagger.Api.GHGAccountingApi

All URIs are relative to *https://api.corrently.io/v2.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**Ghgclearingsettlements**](GHGAccountingApi.md#ghgclearingsettlements) | **GET** /ghgclearing/settlements | List of all settlements availabe for a given clearing
[**Ghgcreateclearing**](GHGAccountingApi.md#ghgcreateclearing) | **GET** /ghgclearing/create | Create new accounting organzition
[**Ghgoraclecreate**](GHGAccountingApi.md#ghgoraclecreate) | **GET** /ghgoracle/create | Create new oracle service

<a name="ghgclearingsettlements"></a>
# **Ghgclearingsettlements**
> void Ghgclearingsettlements ()

List of all settlements availabe for a given clearing

Full inner consensus chain that builds up a balance sheet for greenhouse gases.  

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GhgclearingsettlementsExample
    {
        public void main()
        {
            var apiInstance = new GHGAccountingApi();

            try
            {
                // List of all settlements availabe for a given clearing
                apiInstance.Ghgclearingsettlements();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GHGAccountingApi.Ghgclearingsettlements: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="ghgcreateclearing"></a>
# **Ghgcreateclearing**
> void Ghgcreateclearing ()

Create new accounting organzition

Creates a new organization/entity to build a greenhouse gas balance sheet for. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GhgcreateclearingExample
    {
        public void main()
        {
            var apiInstance = new GHGAccountingApi();

            try
            {
                // Create new accounting organzition
                apiInstance.Ghgcreateclearing();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GHGAccountingApi.Ghgcreateclearing: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="ghgoraclecreate"></a>
# **Ghgoraclecreate**
> void Ghgoraclecreate ()

Create new oracle service

Creates a new orgacle service like a meterpoint operation or manual protocol.  

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class GhgoraclecreateExample
    {
        public void main()
        {
            var apiInstance = new GHGAccountingApi();

            try
            {
                // Create new oracle service
                apiInstance.Ghgoraclecreate();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling GHGAccountingApi.Ghgoraclecreate: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
