# IO.Swagger.Api.CO2OffsetApi

All URIs are relative to *https://api.corrently.io/v2.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**Co2certificate**](CO2OffsetApi.md#co2certificate) | **GET** /co2/certificate | Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).
[**Co2checkout**](CO2OffsetApi.md#co2checkout) | **GET** /co2/basket | Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.
[**Co2compare**](CO2OffsetApi.md#co2compare) | **GET** /co2/comparable | Compare grams of CO2 with different use cases.
[**Co2compensate**](CO2OffsetApi.md#co2compensate) | **GET** /co2/compensate | Direct checkout (buy) co2 compensation
[**Co2findByOwner**](CO2OffsetApi.md#co2findbyowner) | **GET** /co2/findByOwner | Retrieve list of certificates owned by provided Digital ID
[**Co2price**](CO2OffsetApi.md#co2price) | **GET** /co2/price | Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.
[**Co2sources**](CO2OffsetApi.md#co2sources) | **GET** /co2/sources | Latest list of co2 compensation (offset) sources.

<a name="co2certificate"></a>
# **Co2certificate**
> Co2certificate Co2certificate (string compensation = null)

Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).

EU-GDPR complient retrieval of dataset associated to this certificate. <ul><li>Compensation Path</li><li>Digital Signature(s)</li><li>Public Meta Information</li><li>CO2 Offset source (Project)</li><li>Transaction Information</li></ul> Use this endpoint for onthe-fly online rendering of certific data. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class Co2certificateExample
    {
        public void main()
        {
            var apiInstance = new CO2OffsetApi();
            var compensation = compensation_example;  // string | Digital Identity of a certificate to validate. (optional) 

            try
            {
                // Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).
                Co2certificate result = apiInstance.Co2certificate(compensation);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CO2OffsetApi.Co2certificate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **compensation** | **string**| Digital Identity of a certificate to validate. | [optional] 

### Return type

[**Co2certificate**](Co2certificate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="co2checkout"></a>
# **Co2checkout**
> List<Co2basket> Co2checkout (decimal? liter = null, decimal? co2 = null, decimal? kwh = null, string intermediate = null)

Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.

Basket for authenticated accounts (mass operations). On first call you get an intermediate in the responds that you might use to update (eq. add more co2 offset). However you will always receive a new intermediate. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class Co2checkoutExample
    {
        public void main()
        {
            var apiInstance = new CO2OffsetApi();
            var liter = 1.2;  // decimal? | Liter of fuel to compensate. (optional) 
            var co2 = 1.2;  // decimal? | CO2 equivalence in gram to compensate (optional) 
            var kwh = 1.2;  // decimal? | Kilo Watt hours of electricity to co2 offset. (optional) 
            var intermediate = intermediate_example;  // string | Optional intermediate certificate to update (optional) 

            try
            {
                // Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.
                List&lt;Co2basket&gt; result = apiInstance.Co2checkout(liter, co2, kwh, intermediate);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CO2OffsetApi.Co2checkout: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **decimal?**| Liter of fuel to compensate. | [optional] 
 **co2** | **decimal?**| CO2 equivalence in gram to compensate | [optional] 
 **kwh** | **decimal?**| Kilo Watt hours of electricity to co2 offset. | [optional] 
 **intermediate** | **string**| Optional intermediate certificate to update | [optional] 

### Return type

[**List<Co2basket>**](Co2basket.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="co2compare"></a>
# **Co2compare**
> List<Comperators> Co2compare (int? co2 = null)

Compare grams of CO2 with different use cases.

Available results include:<ul><li>gallons of gasoline consumed</li><li>gallons of diesel consumed</li><li>passenger vehicles driven for one year</li><li>tanker trucks worth of gasoline</li><li>incandescent lamps switch to LEDs</li><li>homes powered for a year</li><li>urban tree seedlings grown for 10 years</li><li>railcars of coal burned</li><li>coal-fired power plants in one year</li></ul>

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class Co2compareExample
    {
        public void main()
        {
            var apiInstance = new CO2OffsetApi();
            var co2 = 56;  // int? | CO2 equivalence gramms to compare with (optional) 

            try
            {
                // Compare grams of CO2 with different use cases.
                List&lt;Comperators&gt; result = apiInstance.Co2compare(co2);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CO2OffsetApi.Co2compare: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **co2** | **int?**| CO2 equivalence gramms to compare with | [optional] 

### Return type

[**List<Comperators>**](Comperators.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="co2compensate"></a>
# **Co2compensate**
> List<string> Co2compensate (decimal? liter = null, decimal? co2 = null, decimal? kwh = null)

Direct checkout (buy) co2 compensation

At co2offset.io , compensations represent a purchase of carbon offsets or negative emissions by mass. Place compensation orders directly if you know the amount of carbon dioxide you would like to sequester. You might call the /price API endpoint prior to a checkout to get latest pricing information. This method returns a URL for direct checkout using Stripe. All CO2 offset prices are based on VCS Verified CO2 Emission Reduction In accordance with the requirements of ISO 14064-1. CO2 prices are actual market prices and may change every hour. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class Co2compensateExample
    {
        public void main()
        {
            var apiInstance = new CO2OffsetApi();
            var liter = 1.2;  // decimal? | Liter of fuel to compensate. (optional) 
            var co2 = 1.2;  // decimal? | CO2 equivalence in gram to compensate (optional) 
            var kwh = 1.2;  // decimal? | Kilo Watt hours of electricity to co2 offset. (optional) 

            try
            {
                // Direct checkout (buy) co2 compensation
                List&lt;string&gt; result = apiInstance.Co2compensate(liter, co2, kwh);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CO2OffsetApi.Co2compensate: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **decimal?**| Liter of fuel to compensate. | [optional] 
 **co2** | **decimal?**| CO2 equivalence in gram to compensate | [optional] 
 **kwh** | **decimal?**| Kilo Watt hours of electricity to co2 offset. | [optional] 

### Return type

**List<string>**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="co2findbyowner"></a>
# **Co2findByOwner**
> List<Co2certificate> Co2findByOwner (string owner = null)

Retrieve list of certificates owned by provided Digital ID

Allows to get a list of all certificates associated to an owner. Part of the CO2 Offset Ledger API. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class Co2findByOwnerExample
    {
        public void main()
        {
            var apiInstance = new CO2OffsetApi();
            var owner = owner_example;  // string | Digital ID of an Owner. (optional) 

            try
            {
                // Retrieve list of certificates owned by provided Digital ID
                List&lt;Co2certificate&gt; result = apiInstance.Co2findByOwner(owner);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CO2OffsetApi.Co2findByOwner: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **owner** | **string**| Digital ID of an Owner. | [optional] 

### Return type

[**List<Co2certificate>**](Co2certificate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="co2price"></a>
# **Co2price**
> Co2price Co2price (int? liter = null, int? co2 = null, int? kwh = null)

Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.

All CO2 offset prices are based on VCS Verified CO2 Emission Reduction In accordance with the requirements of ISO 14064-1. CO2 prices are actual market prices and may change every hour. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class Co2priceExample
    {
        public void main()
        {
            var apiInstance = new CO2OffsetApi();
            var liter = 56;  // int? | Liter of fuel to compensate. (optional) 
            var co2 = 56;  // int? | CO2 equivalence in gram to compensate (optional) 
            var kwh = 56;  // int? | Kilo Watt hours of electricity to co2 offset. (optional) 

            try
            {
                // Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.
                Co2price result = apiInstance.Co2price(liter, co2, kwh);
                Debug.WriteLine(result);
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CO2OffsetApi.Co2price: " + e.Message );
            }
        }
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **int?**| Liter of fuel to compensate. | [optional] 
 **co2** | **int?**| CO2 equivalence in gram to compensate | [optional] 
 **kwh** | **int?**| Kilo Watt hours of electricity to co2 offset. | [optional] 

### Return type

[**Co2price**](Co2price.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
<a name="co2sources"></a>
# **Co2sources**
> void Co2sources ()

Latest list of co2 compensation (offset) sources.

Valid and certified sources of co2 compensation. 

### Example
```csharp
using System;
using System.Diagnostics;
using IO.Swagger.Api;
using IO.Swagger.Client;
using IO.Swagger.Model;

namespace Example
{
    public class Co2sourcesExample
    {
        public void main()
        {
            var apiInstance = new CO2OffsetApi();

            try
            {
                // Latest list of co2 compensation (offset) sources.
                apiInstance.Co2sources();
            }
            catch (Exception e)
            {
                Debug.Print("Exception when calling CO2OffsetApi.Co2sources: " + e.Message );
            }
        }
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)
