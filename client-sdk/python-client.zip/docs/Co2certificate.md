# Co2certificate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**compensation** | **str** | Digital Identity of CO2 compensation certificate. | [optional] 
**co2** | **int** | Gram CO2eq covered by this certificate | [optional] 
**co2requested** | **int** | Requested CO2 to offset. Might be less than actual co2 covered by certficate due to minimum amounts. | [optional] 
**signature** | **str** | Digital Signature as generated during transfer of ownership. | [optional] 
**owner** | **str** | Digital Identity of owner of this certificate | [optional] 
**tree** | **str** | Digital Identity of actual tree in case type of compensation is planting a tree. | [optional] 
**meta** | **object** | Meta Information attached during transfer of ownership. Covers fields like original activity etc..  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

