# swagger_client.CO2OffsetApi

All URIs are relative to *https://api.corrently.io/v2.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**co2certificate**](CO2OffsetApi.md#co2certificate) | **GET** /co2/certificate | Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).
[**co2checkout**](CO2OffsetApi.md#co2checkout) | **GET** /co2/basket | Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.
[**co2compare**](CO2OffsetApi.md#co2compare) | **GET** /co2/comparable | Compare grams of CO2 with different use cases.
[**co2compensate**](CO2OffsetApi.md#co2compensate) | **GET** /co2/compensate | Direct checkout (buy) co2 compensation
[**co2find_by_owner**](CO2OffsetApi.md#co2find_by_owner) | **GET** /co2/findByOwner | Retrieve list of certificates owned by provided Digital ID
[**co2price**](CO2OffsetApi.md#co2price) | **GET** /co2/price | Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.
[**co2sources**](CO2OffsetApi.md#co2sources) | **GET** /co2/sources | Latest list of co2 compensation (offset) sources.

# **co2certificate**
> Co2certificate co2certificate(compensation=compensation)

Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).

EU-GDPR complient retrieval of dataset associated to this certificate. <ul><li>Compensation Path</li><li>Digital Signature(s)</li><li>Public Meta Information</li><li>CO2 Offset source (Project)</li><li>Transaction Information</li></ul> Use this endpoint for onthe-fly online rendering of certific data. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CO2OffsetApi()
compensation = 'compensation_example' # str | Digital Identity of a certificate to validate. (optional)

try:
    # Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).
    api_response = api_instance.co2certificate(compensation=compensation)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CO2OffsetApi->co2certificate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **compensation** | **str**| Digital Identity of a certificate to validate. | [optional] 

### Return type

[**Co2certificate**](Co2certificate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **co2checkout**
> list[Co2basket] co2checkout(liter=liter, co2=co2, kwh=kwh, intermediate=intermediate)

Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.

Basket for authenticated accounts (mass operations). On first call you get an intermediate in the responds that you might use to update (eq. add more co2 offset). However you will always receive a new intermediate. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CO2OffsetApi()
liter = 1.2 # float | Liter of fuel to compensate. (optional)
co2 = 1.2 # float | CO2 equivalence in gram to compensate (optional)
kwh = 1.2 # float | Kilo Watt hours of electricity to co2 offset. (optional)
intermediate = 'intermediate_example' # str | Optional intermediate certificate to update (optional)

try:
    # Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.
    api_response = api_instance.co2checkout(liter=liter, co2=co2, kwh=kwh, intermediate=intermediate)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CO2OffsetApi->co2checkout: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **float**| Liter of fuel to compensate. | [optional] 
 **co2** | **float**| CO2 equivalence in gram to compensate | [optional] 
 **kwh** | **float**| Kilo Watt hours of electricity to co2 offset. | [optional] 
 **intermediate** | **str**| Optional intermediate certificate to update | [optional] 

### Return type

[**list[Co2basket]**](Co2basket.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **co2compare**
> list[Comperators] co2compare(co2=co2)

Compare grams of CO2 with different use cases.

Available results include:<ul><li>gallons of gasoline consumed</li><li>gallons of diesel consumed</li><li>passenger vehicles driven for one year</li><li>tanker trucks worth of gasoline</li><li>incandescent lamps switch to LEDs</li><li>homes powered for a year</li><li>urban tree seedlings grown for 10 years</li><li>railcars of coal burned</li><li>coal-fired power plants in one year</li></ul>

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CO2OffsetApi()
co2 = 56 # int | CO2 equivalence gramms to compare with (optional)

try:
    # Compare grams of CO2 with different use cases.
    api_response = api_instance.co2compare(co2=co2)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CO2OffsetApi->co2compare: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **co2** | **int**| CO2 equivalence gramms to compare with | [optional] 

### Return type

[**list[Comperators]**](Comperators.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **co2compensate**
> list[Co2compensate] co2compensate(liter=liter, co2=co2, kwh=kwh)

Direct checkout (buy) co2 compensation

At co2offset.io , compensations represent a purchase of carbon offsets or negative emissions by mass. Place compensation orders directly if you know the amount of carbon dioxide you would like to sequester. You might call the /price API endpoint prior to a checkout to get latest pricing information. This method returns a URL for direct checkout using Stripe. All CO2 offset prices are based on VCS Verified CO2 Emission Reduction In accordance with the requirements of ISO 14064-1. CO2 prices are actual market prices and may change every hour. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CO2OffsetApi()
liter = 1.2 # float | Liter of fuel to compensate. (optional)
co2 = 1.2 # float | CO2 equivalence in gram to compensate (optional)
kwh = 1.2 # float | Kilo Watt hours of electricity to co2 offset. (optional)

try:
    # Direct checkout (buy) co2 compensation
    api_response = api_instance.co2compensate(liter=liter, co2=co2, kwh=kwh)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CO2OffsetApi->co2compensate: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **float**| Liter of fuel to compensate. | [optional] 
 **co2** | **float**| CO2 equivalence in gram to compensate | [optional] 
 **kwh** | **float**| Kilo Watt hours of electricity to co2 offset. | [optional] 

### Return type

[**list[Co2compensate]**](Co2compensate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **co2find_by_owner**
> list[Co2certificate] co2find_by_owner(owner=owner)

Retrieve list of certificates owned by provided Digital ID

Allows to get a list of all certificates associated to an owner. Part of the CO2 Offset Ledger API. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CO2OffsetApi()
owner = 'owner_example' # str | Digital ID of an Owner. (optional)

try:
    # Retrieve list of certificates owned by provided Digital ID
    api_response = api_instance.co2find_by_owner(owner=owner)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CO2OffsetApi->co2find_by_owner: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **owner** | **str**| Digital ID of an Owner. | [optional] 

### Return type

[**list[Co2certificate]**](Co2certificate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **co2price**
> Co2price co2price(liter=liter, co2=co2, kwh=kwh)

Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.

All CO2 offset prices are based on VCS Verified CO2 Emission Reduction In accordance with the requirements of ISO 14064-1. CO2 prices are actual market prices and may change every hour. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CO2OffsetApi()
liter = 56 # int | Liter of fuel to compensate. (optional)
co2 = 56 # int | CO2 equivalence in gram to compensate (optional)
kwh = 56 # int | Kilo Watt hours of electricity to co2 offset. (optional)

try:
    # Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.
    api_response = api_instance.co2price(liter=liter, co2=co2, kwh=kwh)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling CO2OffsetApi->co2price: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **int**| Liter of fuel to compensate. | [optional] 
 **co2** | **int**| CO2 equivalence in gram to compensate | [optional] 
 **kwh** | **int**| Kilo Watt hours of electricity to co2 offset. | [optional] 

### Return type

[**Co2price**](Co2price.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **co2sources**
> co2sources()

Latest list of co2 compensation (offset) sources.

Valid and certified sources of co2 compensation. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CO2OffsetApi()

try:
    # Latest list of co2 compensation (offset) sources.
    api_instance.co2sources()
except ApiException as e:
    print("Exception when calling CO2OffsetApi->co2sources: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

