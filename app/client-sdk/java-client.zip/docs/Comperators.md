# Comperators

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Nature/Kind to compare with |  [optional]
**value** | [**BigDecimal**](BigDecimal.md) | Quantity |  [optional]
**units** | **String** | units of this nature/kind |  [optional]
**description** | **String** | Quantity calculation description |  [optional]
