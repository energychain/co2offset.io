# GhgAccountingApi

All URIs are relative to *https://api.corrently.io/v2.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ghgclearingsettlements**](GhgAccountingApi.md#ghgclearingsettlements) | **GET** /ghgclearing/settlements | List of all settlements availabe for a given clearing
[**ghgcreateclearing**](GhgAccountingApi.md#ghgcreateclearing) | **GET** /ghgclearing/create | Create new accounting organzition
[**ghgoraclecreate**](GhgAccountingApi.md#ghgoraclecreate) | **GET** /ghgoracle/create | Create new oracle service

<a name="ghgclearingsettlements"></a>
# **ghgclearingsettlements**
> ghgclearingsettlements()

List of all settlements availabe for a given clearing

Full inner consensus chain that builds up a balance sheet for greenhouse gases.  

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.GhgAccountingApi;


GhgAccountingApi apiInstance = new GhgAccountingApi();
try {
    apiInstance.ghgclearingsettlements();
} catch (ApiException e) {
    System.err.println("Exception when calling GhgAccountingApi#ghgclearingsettlements");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="ghgcreateclearing"></a>
# **ghgcreateclearing**
> ghgcreateclearing()

Create new accounting organzition

Creates a new organization/entity to build a greenhouse gas balance sheet for. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.GhgAccountingApi;


GhgAccountingApi apiInstance = new GhgAccountingApi();
try {
    apiInstance.ghgcreateclearing();
} catch (ApiException e) {
    System.err.println("Exception when calling GhgAccountingApi#ghgcreateclearing");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

<a name="ghgoraclecreate"></a>
# **ghgoraclecreate**
> ghgoraclecreate()

Create new oracle service

Creates a new orgacle service like a meterpoint operation or manual protocol.  

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.GhgAccountingApi;


GhgAccountingApi apiInstance = new GhgAccountingApi();
try {
    apiInstance.ghgoraclecreate();
} catch (ApiException e) {
    System.err.println("Exception when calling GhgAccountingApi#ghgoraclecreate");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

