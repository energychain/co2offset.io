# Co2OffsetApi

All URIs are relative to *https://api.corrently.io/v2.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**co2certificate**](Co2OffsetApi.md#co2certificate) | **GET** /co2/certificate | Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).
[**co2checkout**](Co2OffsetApi.md#co2checkout) | **GET** /co2/basket | Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.
[**co2compare**](Co2OffsetApi.md#co2compare) | **GET** /co2/comparable | Compare grams of CO2 with different use cases.
[**co2compensate**](Co2OffsetApi.md#co2compensate) | **GET** /co2/compensate | Direct checkout (buy) co2 compensation
[**co2findByOwner**](Co2OffsetApi.md#co2findByOwner) | **GET** /co2/findByOwner | Retrieve list of certificates owned by provided Digital ID
[**co2price**](Co2OffsetApi.md#co2price) | **GET** /co2/price | Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.
[**co2sources**](Co2OffsetApi.md#co2sources) | **GET** /co2/sources | Latest list of co2 compensation (offset) sources.

<a name="co2certificate"></a>
# **co2certificate**
> Co2certificate co2certificate(compensation)

Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).

EU-GDPR complient retrieval of dataset associated to this certificate. &lt;ul&gt;&lt;li&gt;Compensation Path&lt;/li&gt;&lt;li&gt;Digital Signature(s)&lt;/li&gt;&lt;li&gt;Public Meta Information&lt;/li&gt;&lt;li&gt;CO2 Offset source (Project)&lt;/li&gt;&lt;li&gt;Transaction Information&lt;/li&gt;&lt;/ul&gt; Use this endpoint for onthe-fly online rendering of certific data. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.Co2OffsetApi;


Co2OffsetApi apiInstance = new Co2OffsetApi();
String compensation = "compensation_example"; // String | Digital Identity of a certificate to validate.
try {
    Co2certificate result = apiInstance.co2certificate(compensation);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling Co2OffsetApi#co2certificate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **compensation** | **String**| Digital Identity of a certificate to validate. | [optional]

### Return type

[**Co2certificate**](Co2certificate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="co2checkout"></a>
# **co2checkout**
> List&lt;Co2basket&gt; co2checkout(liter, co2, kwh, intermediate)

Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.

Basket for authenticated accounts (mass operations). On first call you get an intermediate in the responds that you might use to update (eq. add more co2 offset). However you will always receive a new intermediate. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.Co2OffsetApi;


Co2OffsetApi apiInstance = new Co2OffsetApi();
BigDecimal liter = new BigDecimal(); // BigDecimal | Liter of fuel to compensate.
BigDecimal co2 = new BigDecimal(); // BigDecimal | CO2 equivalence in gram to compensate
BigDecimal kwh = new BigDecimal(); // BigDecimal | Kilo Watt hours of electricity to co2 offset.
String intermediate = "intermediate_example"; // String | Optional intermediate certificate to update
try {
    List<Co2basket> result = apiInstance.co2checkout(liter, co2, kwh, intermediate);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling Co2OffsetApi#co2checkout");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **BigDecimal**| Liter of fuel to compensate. | [optional]
 **co2** | **BigDecimal**| CO2 equivalence in gram to compensate | [optional]
 **kwh** | **BigDecimal**| Kilo Watt hours of electricity to co2 offset. | [optional]
 **intermediate** | **String**| Optional intermediate certificate to update | [optional]

### Return type

[**List&lt;Co2basket&gt;**](Co2basket.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="co2compare"></a>
# **co2compare**
> List&lt;Comperators&gt; co2compare(co2)

Compare grams of CO2 with different use cases.

Available results include:&lt;ul&gt;&lt;li&gt;gallons of gasoline consumed&lt;/li&gt;&lt;li&gt;gallons of diesel consumed&lt;/li&gt;&lt;li&gt;passenger vehicles driven for one year&lt;/li&gt;&lt;li&gt;tanker trucks worth of gasoline&lt;/li&gt;&lt;li&gt;incandescent lamps switch to LEDs&lt;/li&gt;&lt;li&gt;homes powered for a year&lt;/li&gt;&lt;li&gt;urban tree seedlings grown for 10 years&lt;/li&gt;&lt;li&gt;railcars of coal burned&lt;/li&gt;&lt;li&gt;coal-fired power plants in one year&lt;/li&gt;&lt;/ul&gt;

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.Co2OffsetApi;


Co2OffsetApi apiInstance = new Co2OffsetApi();
Integer co2 = 56; // Integer | CO2 equivalence gramms to compare with
try {
    List<Comperators> result = apiInstance.co2compare(co2);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling Co2OffsetApi#co2compare");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **co2** | **Integer**| CO2 equivalence gramms to compare with | [optional]

### Return type

[**List&lt;Comperators&gt;**](Comperators.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="co2compensate"></a>
# **co2compensate**
> List&lt;String&gt; co2compensate(liter, co2, kwh)

Direct checkout (buy) co2 compensation

At co2offset.io , compensations represent a purchase of carbon offsets or negative emissions by mass. Place compensation orders directly if you know the amount of carbon dioxide you would like to sequester. You might call the /price API endpoint prior to a checkout to get latest pricing information. This method returns a URL for direct checkout using Stripe. All CO2 offset prices are based on VCS Verified CO2 Emission Reduction In accordance with the requirements of ISO 14064-1. CO2 prices are actual market prices and may change every hour. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.Co2OffsetApi;


Co2OffsetApi apiInstance = new Co2OffsetApi();
BigDecimal liter = new BigDecimal(); // BigDecimal | Liter of fuel to compensate.
BigDecimal co2 = new BigDecimal(); // BigDecimal | CO2 equivalence in gram to compensate
BigDecimal kwh = new BigDecimal(); // BigDecimal | Kilo Watt hours of electricity to co2 offset.
try {
    List<String> result = apiInstance.co2compensate(liter, co2, kwh);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling Co2OffsetApi#co2compensate");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **BigDecimal**| Liter of fuel to compensate. | [optional]
 **co2** | **BigDecimal**| CO2 equivalence in gram to compensate | [optional]
 **kwh** | **BigDecimal**| Kilo Watt hours of electricity to co2 offset. | [optional]

### Return type

**List&lt;String&gt;**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="co2findByOwner"></a>
# **co2findByOwner**
> List&lt;Co2certificate&gt; co2findByOwner(owner)

Retrieve list of certificates owned by provided Digital ID

Allows to get a list of all certificates associated to an owner. Part of the CO2 Offset Ledger API. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.Co2OffsetApi;


Co2OffsetApi apiInstance = new Co2OffsetApi();
String owner = "owner_example"; // String | Digital ID of an Owner.
try {
    List<Co2certificate> result = apiInstance.co2findByOwner(owner);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling Co2OffsetApi#co2findByOwner");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **owner** | **String**| Digital ID of an Owner. | [optional]

### Return type

[**List&lt;Co2certificate&gt;**](Co2certificate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="co2price"></a>
# **co2price**
> Co2price co2price(liter, co2, kwh)

Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.

All CO2 offset prices are based on VCS Verified CO2 Emission Reduction In accordance with the requirements of ISO 14064-1. CO2 prices are actual market prices and may change every hour. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.Co2OffsetApi;


Co2OffsetApi apiInstance = new Co2OffsetApi();
Integer liter = 56; // Integer | Liter of fuel to compensate.
Integer co2 = 56; // Integer | CO2 equivalence in gram to compensate
Integer kwh = 56; // Integer | Kilo Watt hours of electricity to co2 offset.
try {
    Co2price result = apiInstance.co2price(liter, co2, kwh);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling Co2OffsetApi#co2price");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **Integer**| Liter of fuel to compensate. | [optional]
 **co2** | **Integer**| CO2 equivalence in gram to compensate | [optional]
 **kwh** | **Integer**| Kilo Watt hours of electricity to co2 offset. | [optional]

### Return type

[**Co2price**](Co2price.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

<a name="co2sources"></a>
# **co2sources**
> co2sources()

Latest list of co2 compensation (offset) sources.

Valid and certified sources of co2 compensation. 

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.Co2OffsetApi;


Co2OffsetApi apiInstance = new Co2OffsetApi();
try {
    apiInstance.co2sources();
} catch (ApiException e) {
    System.err.println("Exception when calling Co2OffsetApi#co2sources");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

