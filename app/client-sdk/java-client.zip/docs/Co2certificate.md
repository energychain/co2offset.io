# Co2certificate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**compensation** | **String** | Digital Identity of CO2 compensation certificate. |  [optional]
**co2** | **Integer** | Gram CO2eq covered by this certificate |  [optional]
**co2requested** | **Integer** | Requested CO2 to offset. Might be less than actual co2 covered by certficate due to minimum amounts. |  [optional]
**signature** | **String** | Digital Signature as generated during transfer of ownership. |  [optional]
**owner** | **String** | Digital Identity of owner of this certificate |  [optional]
**tree** | **String** | Digital Identity of actual tree in case type of compensation is planting a tree. |  [optional]
**meta** | **Object** | Meta Information attached during transfer of ownership. Covers fields like original activity etc..  |  [optional]
