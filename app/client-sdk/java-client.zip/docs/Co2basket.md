# Co2basket

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**checkout** | **String** | URL for interactive checkout and payment of CO2 offset for a co2 certificate. |  [optional]
**credit** | **Integer** | CO2 credit of your account (if authenticated) |  [optional]
**debit** | **String** | CO2 debit of your account (if authenticated) |  [optional]
**intermediate** | **String** | Temporary Certificate |  [optional]
