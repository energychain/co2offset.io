# Co2price

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**priceCent** | **Integer** | EUR Cent price of co2 offset certificate |  [optional]
**priceEUR** | **String** | EUR price of co2 offset certificate |  [optional]
**reqCO2** | [**BigDecimal**](BigDecimal.md) | Requested CO2 to offset |  [optional]
**getCO2** | [**BigDecimal**](BigDecimal.md) | CO2 offset you receive. Might be more than requested, due to minimum requirements on the market. |  [optional]
**remainCO2** | [**BigDecimal**](BigDecimal.md) | Remaining CO2 (getCO2-reqCO2) |  [optional]
