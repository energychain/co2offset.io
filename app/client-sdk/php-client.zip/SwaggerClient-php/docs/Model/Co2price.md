# Co2price

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**price_cent** | **int** | EUR Cent price of co2 offset certificate | [optional] 
**price_eur** | **string** | EUR price of co2 offset certificate | [optional] 
**req_co2** | **float** | Requested CO2 to offset | [optional] 
**get_co2** | **float** | CO2 offset you receive. Might be more than requested, due to minimum requirements on the market. | [optional] 
**remain_co2** | **float** | Remaining CO2 (getCO2-reqCO2) | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

