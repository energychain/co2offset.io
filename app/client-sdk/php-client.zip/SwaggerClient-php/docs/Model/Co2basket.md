# Co2basket

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**checkout** | **string** | URL for interactive checkout and payment of CO2 offset for a co2 certificate. | [optional] 
**credit** | **int** | CO2 credit of your account (if authenticated) | [optional] 
**debit** | **string** | CO2 debit of your account (if authenticated) | [optional] 
**intermediate** | **string** | Temporary Certificate | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

