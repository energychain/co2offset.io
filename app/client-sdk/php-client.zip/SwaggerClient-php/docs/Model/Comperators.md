# Comperators

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **string** | Nature/Kind to compare with | [optional] 
**value** | **float** | Quantity | [optional] 
**units** | **string** | units of this nature/kind | [optional] 
**description** | **string** | Quantity calculation description | [optional] 

[[Back to Model list]](../../README.md#documentation-for-models) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to README]](../../README.md)

