# Swagger\Client\GHGAccountingApi

All URIs are relative to *https://api.corrently.io/v2.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ghgclearingsettlements**](GHGAccountingApi.md#ghgclearingsettlements) | **GET** /ghgclearing/settlements | List of all settlements availabe for a given clearing
[**ghgcreateclearing**](GHGAccountingApi.md#ghgcreateclearing) | **GET** /ghgclearing/create | Create new accounting organzition
[**ghgoraclecreate**](GHGAccountingApi.md#ghgoraclecreate) | **GET** /ghgoracle/create | Create new oracle service

# **ghgclearingsettlements**
> ghgclearingsettlements()

List of all settlements availabe for a given clearing

Full inner consensus chain that builds up a balance sheet for greenhouse gases.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\GHGAccountingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $apiInstance->ghgclearingsettlements();
} catch (Exception $e) {
    echo 'Exception when calling GHGAccountingApi->ghgclearingsettlements: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **ghgcreateclearing**
> ghgcreateclearing()

Create new accounting organzition

Creates a new organization/entity to build a greenhouse gas balance sheet for.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\GHGAccountingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $apiInstance->ghgcreateclearing();
} catch (Exception $e) {
    echo 'Exception when calling GHGAccountingApi->ghgcreateclearing: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **ghgoraclecreate**
> ghgoraclecreate()

Create new oracle service

Creates a new orgacle service like a meterpoint operation or manual protocol.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\GHGAccountingApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $apiInstance->ghgoraclecreate();
} catch (Exception $e) {
    echo 'Exception when calling GHGAccountingApi->ghgoraclecreate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

