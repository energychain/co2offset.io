# Swagger\Client\CO2OffsetApi

All URIs are relative to *https://api.corrently.io/v2.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**co2certificate**](CO2OffsetApi.md#co2certificate) | **GET** /co2/certificate | Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).
[**co2checkout**](CO2OffsetApi.md#co2checkout) | **GET** /co2/basket | Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.
[**co2compare**](CO2OffsetApi.md#co2compare) | **GET** /co2/comparable | Compare grams of CO2 with different use cases.
[**co2compensate**](CO2OffsetApi.md#co2compensate) | **GET** /co2/compensate | Direct checkout (buy) co2 compensation
[**co2findByOwner**](CO2OffsetApi.md#co2findbyowner) | **GET** /co2/findByOwner | Retrieve list of certificates owned by provided Digital ID
[**co2price**](CO2OffsetApi.md#co2price) | **GET** /co2/price | Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.
[**co2sources**](CO2OffsetApi.md#co2sources) | **GET** /co2/sources | Latest list of co2 compensation (offset) sources.

# **co2certificate**
> \Swagger\Client\Model\Co2certificate co2certificate($compensation)

Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).

EU-GDPR complient retrieval of dataset associated to this certificate. <ul><li>Compensation Path</li><li>Digital Signature(s)</li><li>Public Meta Information</li><li>CO2 Offset source (Project)</li><li>Transaction Information</li></ul> Use this endpoint for onthe-fly online rendering of certific data.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CO2OffsetApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$compensation = "compensation_example"; // string | Digital Identity of a certificate to validate.

try {
    $result = $apiInstance->co2certificate($compensation);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CO2OffsetApi->co2certificate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **compensation** | **string**| Digital Identity of a certificate to validate. | [optional]

### Return type

[**\Swagger\Client\Model\Co2certificate**](../Model/Co2certificate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **co2checkout**
> \Swagger\Client\Model\Co2basket[] co2checkout($liter, $co2, $kwh, $intermediate)

Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.

Basket for authenticated accounts (mass operations). On first call you get an intermediate in the responds that you might use to update (eq. add more co2 offset). However you will always receive a new intermediate.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CO2OffsetApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$liter = 1.2; // float | Liter of fuel to compensate.
$co2 = 1.2; // float | CO2 equivalence in gram to compensate
$kwh = 1.2; // float | Kilo Watt hours of electricity to co2 offset.
$intermediate = "intermediate_example"; // string | Optional intermediate certificate to update

try {
    $result = $apiInstance->co2checkout($liter, $co2, $kwh, $intermediate);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CO2OffsetApi->co2checkout: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **float**| Liter of fuel to compensate. | [optional]
 **co2** | **float**| CO2 equivalence in gram to compensate | [optional]
 **kwh** | **float**| Kilo Watt hours of electricity to co2 offset. | [optional]
 **intermediate** | **string**| Optional intermediate certificate to update | [optional]

### Return type

[**\Swagger\Client\Model\Co2basket[]**](../Model/Co2basket.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **co2compare**
> \Swagger\Client\Model\Comperators[] co2compare($co2)

Compare grams of CO2 with different use cases.

Available results include:<ul><li>gallons of gasoline consumed</li><li>gallons of diesel consumed</li><li>passenger vehicles driven for one year</li><li>tanker trucks worth of gasoline</li><li>incandescent lamps switch to LEDs</li><li>homes powered for a year</li><li>urban tree seedlings grown for 10 years</li><li>railcars of coal burned</li><li>coal-fired power plants in one year</li></ul>

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CO2OffsetApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$co2 = 56; // int | CO2 equivalence gramms to compare with

try {
    $result = $apiInstance->co2compare($co2);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CO2OffsetApi->co2compare: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **co2** | **int**| CO2 equivalence gramms to compare with | [optional]

### Return type

[**\Swagger\Client\Model\Comperators[]**](../Model/Comperators.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **co2compensate**
> \Swagger\Client\Model\Co2compensate[] co2compensate($liter, $co2, $kwh)

Direct checkout (buy) co2 compensation

At co2offset.io , compensations represent a purchase of carbon offsets or negative emissions by mass. Place compensation orders directly if you know the amount of carbon dioxide you would like to sequester. You might call the /price API endpoint prior to a checkout to get latest pricing information. This method returns a URL for direct checkout using Stripe. All CO2 offset prices are based on VCS Verified CO2 Emission Reduction In accordance with the requirements of ISO 14064-1. CO2 prices are actual market prices and may change every hour.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CO2OffsetApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$liter = 1.2; // float | Liter of fuel to compensate.
$co2 = 1.2; // float | CO2 equivalence in gram to compensate
$kwh = 1.2; // float | Kilo Watt hours of electricity to co2 offset.

try {
    $result = $apiInstance->co2compensate($liter, $co2, $kwh);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CO2OffsetApi->co2compensate: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **float**| Liter of fuel to compensate. | [optional]
 **co2** | **float**| CO2 equivalence in gram to compensate | [optional]
 **kwh** | **float**| Kilo Watt hours of electricity to co2 offset. | [optional]

### Return type

[**\Swagger\Client\Model\Co2compensate[]**](../Model/Co2compensate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **co2findByOwner**
> \Swagger\Client\Model\Co2certificate[] co2findByOwner($owner)

Retrieve list of certificates owned by provided Digital ID

Allows to get a list of all certificates associated to an owner. Part of the CO2 Offset Ledger API.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CO2OffsetApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$owner = "owner_example"; // string | Digital ID of an Owner.

try {
    $result = $apiInstance->co2findByOwner($owner);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CO2OffsetApi->co2findByOwner: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **owner** | **string**| Digital ID of an Owner. | [optional]

### Return type

[**\Swagger\Client\Model\Co2certificate[]**](../Model/Co2certificate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **co2price**
> \Swagger\Client\Model\Co2price co2price($liter, $co2, $kwh)

Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.

All CO2 offset prices are based on VCS Verified CO2 Emission Reduction In accordance with the requirements of ISO 14064-1. CO2 prices are actual market prices and may change every hour.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CO2OffsetApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$liter = 56; // int | Liter of fuel to compensate.
$co2 = 56; // int | CO2 equivalence in gram to compensate
$kwh = 56; // int | Kilo Watt hours of electricity to co2 offset.

try {
    $result = $apiInstance->co2price($liter, $co2, $kwh);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CO2OffsetApi->co2price: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **int**| Liter of fuel to compensate. | [optional]
 **co2** | **int**| CO2 equivalence in gram to compensate | [optional]
 **kwh** | **int**| Kilo Watt hours of electricity to co2 offset. | [optional]

### Return type

[**\Swagger\Client\Model\Co2price**](../Model/Co2price.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **co2sources**
> co2sources()

Latest list of co2 compensation (offset) sources.

Valid and certified sources of co2 compensation.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CO2OffsetApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $apiInstance->co2sources();
} catch (Exception $e) {
    echo 'Exception when calling CO2OffsetApi->co2sources: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

