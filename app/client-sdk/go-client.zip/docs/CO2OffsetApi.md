# {{classname}}

All URIs are relative to *https://api.corrently.io/v2.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**Co2certificate**](CO2OffsetApi.md#Co2certificate) | **Get** /co2/certificate | Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).
[**Co2checkout**](CO2OffsetApi.md#Co2checkout) | **Get** /co2/basket | Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.
[**Co2compare**](CO2OffsetApi.md#Co2compare) | **Get** /co2/comparable | Compare grams of CO2 with different use cases.
[**Co2compensate**](CO2OffsetApi.md#Co2compensate) | **Get** /co2/compensate | Direct checkout (buy) co2 compensation
[**Co2findByOwner**](CO2OffsetApi.md#Co2findByOwner) | **Get** /co2/findByOwner | Retrieve list of certificates owned by provided Digital ID
[**Co2price**](CO2OffsetApi.md#Co2price) | **Get** /co2/price | Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.
[**Co2sources**](CO2OffsetApi.md#Co2sources) | **Get** /co2/sources | Latest list of co2 compensation (offset) sources.

# **Co2certificate**
> Co2certificate Co2certificate(ctx, optional)
Retrieve CO2 offset certrificate data and validates (Proof of Identity, Consensus check).

EU-GDPR complient retrieval of dataset associated to this certificate. <ul><li>Compensation Path</li><li>Digital Signature(s)</li><li>Public Meta Information</li><li>CO2 Offset source (Project)</li><li>Transaction Information</li></ul> Use this endpoint for onthe-fly online rendering of certific data. 

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***CO2OffsetApiCo2certificateOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a CO2OffsetApiCo2certificateOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **compensation** | **optional.String**| Digital Identity of a certificate to validate. | 

### Return type

[**Co2certificate**](co2certificate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **Co2checkout**
> []Co2basket Co2checkout(ctx, optional)
Checkout (buy) co2 compensation. Will create an immutable basket that might be altered using the optional intermediate parameter.

Basket for authenticated accounts (mass operations). On first call you get an intermediate in the responds that you might use to update (eq. add more co2 offset). However you will always receive a new intermediate. 

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***CO2OffsetApiCo2checkoutOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a CO2OffsetApiCo2checkoutOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **optional.Float64**| Liter of fuel to compensate. | 
 **co2** | **optional.Float64**| CO2 equivalence in gram to compensate | 
 **kwh** | **optional.Float64**| Kilo Watt hours of electricity to co2 offset. | 
 **intermediate** | **optional.String**| Optional intermediate certificate to update | 

### Return type

[**[]Co2basket**](co2basket.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **Co2compare**
> []Comperators Co2compare(ctx, optional)
Compare grams of CO2 with different use cases.

Available results include:<ul><li>gallons of gasoline consumed</li><li>gallons of diesel consumed</li><li>passenger vehicles driven for one year</li><li>tanker trucks worth of gasoline</li><li>incandescent lamps switch to LEDs</li><li>homes powered for a year</li><li>urban tree seedlings grown for 10 years</li><li>railcars of coal burned</li><li>coal-fired power plants in one year</li></ul>

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***CO2OffsetApiCo2compareOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a CO2OffsetApiCo2compareOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **co2** | **optional.Int32**| CO2 equivalence gramms to compare with | 

### Return type

[**[]Comperators**](comperators.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **Co2compensate**
> []string Co2compensate(ctx, optional)
Direct checkout (buy) co2 compensation

At co2offset.io , compensations represent a purchase of carbon offsets or negative emissions by mass. Place compensation orders directly if you know the amount of carbon dioxide you would like to sequester. You might call the /price API endpoint prior to a checkout to get latest pricing information. This method returns a URL for direct checkout using Stripe. All CO2 offset prices are based on VCS Verified CO2 Emission Reduction In accordance with the requirements of ISO 14064-1. CO2 prices are actual market prices and may change every hour. 

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***CO2OffsetApiCo2compensateOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a CO2OffsetApiCo2compensateOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **optional.Float64**| Liter of fuel to compensate. | 
 **co2** | **optional.Float64**| CO2 equivalence in gram to compensate | 
 **kwh** | **optional.Float64**| Kilo Watt hours of electricity to co2 offset. | 

### Return type

**[]string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **Co2findByOwner**
> []Co2certificate Co2findByOwner(ctx, optional)
Retrieve list of certificates owned by provided Digital ID

Allows to get a list of all certificates associated to an owner. Part of the CO2 Offset Ledger API. 

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***CO2OffsetApiCo2findByOwnerOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a CO2OffsetApiCo2findByOwnerOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **owner** | **optional.String**| Digital ID of an Owner. | 

### Return type

[**[]Co2certificate**](co2certificate.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **Co2price**
> Co2price Co2price(ctx, optional)
Retrieve co2 footprint and compensation prices for either fuel, electricity or directly per CO2e gram.

All CO2 offset prices are based on VCS Verified CO2 Emission Reduction In accordance with the requirements of ISO 14064-1. CO2 prices are actual market prices and may change every hour. 

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***CO2OffsetApiCo2priceOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a CO2OffsetApiCo2priceOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **liter** | **optional.Int32**| Liter of fuel to compensate. | 
 **co2** | **optional.Int32**| CO2 equivalence in gram to compensate | 
 **kwh** | **optional.Int32**| Kilo Watt hours of electricity to co2 offset. | 

### Return type

[**Co2price**](co2price.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **Co2sources**
> Co2sources(ctx, )
Latest list of co2 compensation (offset) sources.

Valid and certified sources of co2 compensation. 

### Required Parameters
This endpoint does not need any parameter.

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

