# Co2price

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PriceCent** | **int32** | EUR Cent price of co2 offset certificate | [optional] [default to null]
**PriceEUR** | **string** | EUR price of co2 offset certificate | [optional] [default to null]
**ReqCO2** | **float64** | Requested CO2 to offset | [optional] [default to null]
**GetCO2** | **float64** | CO2 offset you receive. Might be more than requested, due to minimum requirements on the market. | [optional] [default to null]
**RemainCO2** | **float64** | Remaining CO2 (getCO2-reqCO2) | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

