# Co2certificate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Compensation** | **string** | Digital Identity of CO2 compensation certificate. | [optional] [default to null]
**Co2** | **int32** | Gram CO2eq covered by this certificate | [optional] [default to null]
**Co2requested** | **int32** | Requested CO2 to offset. Might be less than actual co2 covered by certficate due to minimum amounts. | [optional] [default to null]
**Signature** | **string** | Digital Signature as generated during transfer of ownership. | [optional] [default to null]
**Owner** | **string** | Digital Identity of owner of this certificate | [optional] [default to null]
**Tree** | **string** | Digital Identity of actual tree in case type of compensation is planting a tree. | [optional] [default to null]
**Meta** | [***interface{}**](interface{}.md) | Meta Information attached during transfer of ownership. Covers fields like original activity etc..  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

