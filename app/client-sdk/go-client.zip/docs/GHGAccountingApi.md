# {{classname}}

All URIs are relative to *https://api.corrently.io/v2.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**Ghgclearingsettlements**](GHGAccountingApi.md#Ghgclearingsettlements) | **Get** /ghgclearing/settlements | List of all settlements availabe for a given clearing
[**Ghgcreateclearing**](GHGAccountingApi.md#Ghgcreateclearing) | **Get** /ghgclearing/create | Create new accounting organzition
[**Ghgoraclecreate**](GHGAccountingApi.md#Ghgoraclecreate) | **Get** /ghgoracle/create | Create new oracle service

# **Ghgclearingsettlements**
> Ghgclearingsettlements(ctx, )
List of all settlements availabe for a given clearing

Full inner consensus chain that builds up a balance sheet for greenhouse gases.  

### Required Parameters
This endpoint does not need any parameter.

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **Ghgcreateclearing**
> Ghgcreateclearing(ctx, )
Create new accounting organzition

Creates a new organization/entity to build a greenhouse gas balance sheet for. 

### Required Parameters
This endpoint does not need any parameter.

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **Ghgoraclecreate**
> Ghgoraclecreate(ctx, )
Create new oracle service

Creates a new orgacle service like a meterpoint operation or manual protocol.  

### Required Parameters
This endpoint does not need any parameter.

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

